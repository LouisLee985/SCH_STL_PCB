# Homekit_Air_Conditioner
PCB板1.2mm厚度打样，可与3D外壳适配。
<div align="center">
<br><img src="/image/AC_IR_Homekit_5V1A_3.0_0402.jpg"  width="60%" alt="5V1A版本PCB-0402"/>
<br><img src="/image/AC_IR_Homekit_5V1A_3.0_0603.jpg"  width="60%" alt="5V1A版本PCB-0603"/>
<br><img src="/image/IMG_1000.jpg"  width="60%"/>
</div>

<br>3D打印外壳
<div align="center">
<br><img src="/image/5V1A_stl.jpg"  width="60%"/>
<br><img src="/image/IMG_1001.jpg"  width="60%"/>

<br><img src="/image/IMG_1002.jpg"  width="60%"/>
</div>
<br>外观设计参考：https://github.com/huexpub/IRMQTT
