# Homekit_Air_Conditioner
<br>内置空调机内. 
<br>无需USB公插和红外接收电路, 直接连接到空调数显主板上. 共用主板+5V供电和红外接收. 
<br>需要动手能力和电工维修经验. 

<div align="center">
<br><img src="/image/AC_IR_Homekit_Inside_3.0_0402.jpg" width="50%"/>

<br><img src="/image/IMG_2002.JPG" width="50%"/>

<br><img src="/image/IMG_2003.JPG"  width="50%"/>

<br><img src="/image/IMG_2004.jpg"  width="50%"/>

<br><img src="/image/IMG_2007.jpg"  width="50%"/>

<br><img src="/image/IMG_2029.jpg"  width="50%"/>

<br><img src="/image/IMG_2030.jpg"  width="50%"/>

<br><img src="/image/IMG_2031.JPG"  width="50%"/>
</div>
柜机数显主板, 找出+5V, GND, REV(红外接收数据pin), 同样使用. 
<div align="center">
<br><img src="/image/IMG_2005.JPG"  width="200"/>
</div>
