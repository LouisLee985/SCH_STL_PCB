

/* this file contains generic utilities and functions */

#ifndef UTILS_H_
#define UTILS_H_


double CubicInterpolate(
   double y0,double y1,
   double y2,double y3,
   double mu);




#endif /* UTILS_H_ */
