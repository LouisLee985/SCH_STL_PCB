

#ifndef FTOA_H_
#define FTOA_H_

#define MAX_MANTISA (1000)

int ftoa (float x, char *str, char  prec, char format);



#endif /* FTOA_H_ */
