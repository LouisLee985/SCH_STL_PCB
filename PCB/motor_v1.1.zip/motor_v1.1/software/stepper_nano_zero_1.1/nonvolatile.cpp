
#include "nonvolatile.h"
#include "Flash.h"  //thanks to Kent Larsen for pointing out the lower case error
#include <Arduino.h>




//we use this so we can hard code calibration table
// be sure to set the last word as status flag
// this save time calibrating each time we do a code build
#ifdef NZS_FAST_CAL
__attribute__((__aligned__(FLASH_ROW_SIZE))) const uint16_t NVM_flash[16767]={  //allocates 33280 bytes
#else
__attribute__((__aligned__(FLASH_ROW_SIZE))) const uint16_t NVM_flash[256]={  //allocates 512 bytes
#endif
//59962,60291,60621,60949,61267,61596,61924,62252,62567,62897,63223,63548,63865,64192,64518,64842,65157,65482,274,600,917,1247,1573,1902,2225,2560,2892,3225,3550,3888,4226,4564,4893,5234,5575,5914,6246,6587,6930,7267,7596,7937,8275,8611,8936,9274,9606,9940,10262,10594,10925,11253,11572,11902,12228,12553,12870,13195,13518,13844,14159,14480,14801,15123,15435,15756,16078,16398,16708,17031,17350,17675,17988,18312,18640,18965,19282,19609,19943,20271,20593,20924,21257,21589,21914,22250,22586,22920,23241,23578,23912,24245,24570,24902,25236,25567,25887,26219,26549,26877,27196,27524,27851,28178,28496,28823,29145,29470,29788,30112,30436,30759,31074,31396,31720,32041,32355,32681,33003,33329,33644,33971,34297,34625,34947,35278,35610,35941,36271,36605,36944,37280,37609,37948,38287,38625,38960,39300,39640,39977,40308,40651,40988,41325,41653,41989,42326,42655,42982,43316,43646,43976,44294,44626,44951,45277,45598,45924,46250,46572,46888,47212,47536,47856,48167,48490,48813,49133,49447,49769,50091,50412,50726,51051,51377,51701,52022,52353,52681,53013,53334,53668,53999,54334,54661,54997,55331,55665,55991,56330,56664,57001,57326,57662,57994,58327,58650,58981,59313,59641,

			0xFFFF
};



static_assert (sizeof(nvm_t)<sizeof(NVM_flash), "nvm_t structure larger than allocated memory");




//FLASH_ALLOCATE(NVM_flash, sizeof(nvm_t));


bool nvmWriteCalTable(void *ptrData, uint32_t size)
{
	bool x=true;
	flashWrite(&NVM->CalibrationTable,ptrData,size);
	return true;
}

bool nvmWrite_sPID(float Kp, float Ki, float Kd)
{
	PIDparams_t pid;

	pid.Kp=Kp;
	pid.Ki=Ki;
	pid.Kd=Kd;
	pid.parametersVaild=true;

	flashWrite((void *)&NVM->sPID,&pid,sizeof(pid));
	return true;
}

bool nvmWrite_vPID(float Kp, float Ki, float Kd)
{
	PIDparams_t pid;

	pid.Kp=Kp;
	pid.Ki=Ki;
	pid.Kd=Kd;
	pid.parametersVaild=true;

	flashWrite((void *)&NVM->vPID,&pid,sizeof(pid));
	return true;
}

bool nvmWrite_pPID(float Kp, float Ki, float Kd)
{
	PIDparams_t pid;

	pid.Kp=Kp;
	pid.Ki=Ki;
	pid.Kd=Kd;
	pid.parametersVaild=true;

	flashWrite((void *)&NVM->pPID,&pid,sizeof(pid));
	return true;
}

bool nvmWriteSystemParms(SystemParams_t &systemParams)
{
	systemParams.parametersVaild=true;

	flashWrite((void *)&NVM->SystemParams,&systemParams,sizeof(systemParams));
	return true;
}

bool nvmWriteMotorParms(MotorParams_t &motorParams)
{
	motorParams.parametersVaild=true;

	flashWrite((void *)&NVM->motorParams,&motorParams,sizeof(motorParams));
	return true;
}

bool nvmErase(void)
{
	bool data=false;
	uint16_t cs=0;

	flashWrite((void *)&NVM->CalibrationTable.status,&data,sizeof(data));
	flashWrite((void *)&NVM->sPID.parametersVaild ,&data,sizeof(data));
	flashWrite((void *)&NVM->vPID.parametersVaild ,&data,sizeof(data));
	flashWrite((void *)&NVM->pPID.parametersVaild ,&data,sizeof(data));
	flashWrite((void *)&NVM->motorParams.parametersVaild ,&data,sizeof(data));
	flashWrite((void *)&NVM->SystemParams.parametersVaild ,&data,sizeof(data));
#ifdef NZS_FAST_CAL
	flashWrite((void *)&NVM->FastCal.checkSum,&cs,sizeof(cs));
#endif
}
