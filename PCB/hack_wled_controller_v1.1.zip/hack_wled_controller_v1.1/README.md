Hack Labs RGBLED Controller ：https://www.youtube.com/watch?v=lrZFiLHbFRo&lc=Ugw5ZR2V5kvy2mBF6H14AaABAg                                                                                
Author: HACK实验室                                                                                     
YouTube ID: HACK实验室, welcome to subscribe https://www.youtube.com/channel/UCxFY1FcIYK9d7riTvIh6eiA                                                         
Hack Labs RGBLED Controller is a free download and may be used, modified, evaluated and
distributed without charge provided the user adheres to version three of the GNU
General Public License (GPL) and does not remove the copyright notice or this
text.  The GPL V3 text is available on the gnu.org web site
作者：HACK实验室                                                                                        
B站ID：HACK实验室  欢迎订阅 https://space.bilibili.com/395145107                                                                            
微信公众号：HACK实验室，开源资料唯一发布点，定期分享开源硬件以及有价值的技术文章，欢迎关注.                                                                                                             

